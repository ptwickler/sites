<?php
// $Id: region--highlighted.tpl.php,v 1.1 2010/11/14 03:24:00 shannonlucas Exp $
/**
 * @file
 * The highlighted region for Nitobe.
 */
?>
<?php if ($content): ?>
<div id="highlighted-region" class="<?php echo $classes; ?>">
  <?php echo $content; ?>
</div>
<?php endif; ?>