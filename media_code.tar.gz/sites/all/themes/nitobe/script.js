// $Id: script.js,v 1.2 2010/10/21 02:39:36 shannonlucas Exp $

/**
 * @file script.js
 * General JavaScript functions for the theme. A default file is required to
 * get Drupal to automatically load jQuery.
 */
