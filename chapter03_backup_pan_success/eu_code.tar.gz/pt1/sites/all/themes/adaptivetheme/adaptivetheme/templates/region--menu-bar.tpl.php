<?php if (!empty($content)): ?>
  <div id="menu-bar" class="nav clearfix">
    <?php print $content; ?>
  </div>
<?php endif; ?>
