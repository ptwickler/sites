<?php
// $Id: region--header.tpl.php,v 1.1 2010/11/14 03:24:00 shannonlucas Exp $
/**
 * @file
 * Header region for Nitobe.
 */
?>
<?php if ($content): ?>
<div id="header-region" class="grid-6 <?php echo $classes; ?>">
  <?php echo $content; ?>
</div><!-- /header-region -->
<?php endif; ?>
